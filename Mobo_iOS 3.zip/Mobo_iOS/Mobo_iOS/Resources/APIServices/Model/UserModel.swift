//
//  UserModel.swift
//  Mobo_iOS
//
//  Created by 조경진 on 2019/12/24.
//  Copyright © 2019 조경진. All rights reserved.
//

import UIKit

class UserModel: NSObject {

    
    @objc var profileImageUrl :String?
    @objc var userName :String?
    @objc var uid: String?
    

}

