//
//  MoviewTabOne.swift
//  Mobo_iOS
//
//  Created by 조경진 on 2019/12/23.
//  Copyright © 2019 조경진. All rights reserved.
//

import UIKit

class TimeTableOneViewController: UIViewController {
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print(1)
    }
}
