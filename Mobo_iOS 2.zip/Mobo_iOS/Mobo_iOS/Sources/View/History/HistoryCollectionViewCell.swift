//
//  HistoryCollectionViewCell.swift
//  Mobo_iOS
//
//  Created by 천유정 on 31/12/2019.
//  Copyright © 2019 조경진. All rights reserved.
//

import UIKit

class HistoryCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var date: UILabel!
    @IBOutlet weak var datestatus: UILabel!
    @IBOutlet weak var moviename: UILabel!
    
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var age: UILabel!
    
    @IBOutlet weak var kakaotalk: UILabel!
    
    @IBOutlet weak var profileimg: UIImageView!
    
    
}
